***CASA CONECTADA***
Website Tienda Online
-------------------------------------------------------------------------
#Información General

# Dentro de la carpte web se encuentran todos los ficheros html.
El primer fichero a ejecutar es el index.html.


# Para el apartado de login, se usará de momento en la version de pruebas, el usuario es "ron" y la contraseña es "ron". Todo en minúsculas y sin comillas.
Es el area de administración y de momento solo se accederá para hacer mantenimiento de la página.

#el enlace de la presentación es el siguiente:
https://view.genial.ly/61a89a7d4282470e281b5a94/dossier-copia-casaconectadainterfaces

# Ante cualquier duda contactar con el desarrollador al correo:
ronaldgarcia.20@campuscamara.es